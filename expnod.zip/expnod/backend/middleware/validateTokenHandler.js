const asyncHandler = require("express-async-handler");
const jwt = require("jsonwebtoken");

const validateToken = asyncHandler((req, res, next) => {
    let token;
    const authHeader = req.headers.authorization; // Correctly get the authorization header

    if (authHeader && authHeader.startsWith("Bearer")) {
        token = authHeader.split(" ")[1]; // Extract token from the header
    }

    if (!token) {
        res.status(401);
        throw new Error("User is not authorized, no token");
    }

    jwt.verify(token, process.env.SECRET_KEY, (err, decoded) => {
        if (err) {
            res.status(401);
            throw new Error("User is not authorized");
        }
        req.user = decoded.user; // Assuming the token payload has a 'user' property
        next(); // Call the next middleware or route handler
    });
});

module.exports = validateToken;
